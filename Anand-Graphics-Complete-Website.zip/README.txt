ANAND GRAPHICS & ADVERTISING - COMPLETE WEBSITE

Files:
index.html       Main website
login.html       Customer/Admin login
admin.html       Admin dashboard
firebase.js      Firebase connection
app.js           Shop/cart/order/tracking
auth.js          Signup/login/forgot password
admin.js         Product/order/admin/Excel tools
style.css        Responsive design
firestore.rules  Firestore security rules

Firebase:
Project: anand-graphics
Admin: anandpandey7919@gmail.com

SETUP:
1. Firebase Authentication -> Sign-in method -> Email/Password = Enabled.
2. Firestore database already created.
3. Firestore -> Rules -> paste firestore.rules -> Publish.
4. Upload these website files to hosting.
5. Login with the admin email and the password you set in Firebase.
6. Open admin.html and add products.

EXCEL:
Admin -> Excel -> downloads .xlsx files. Firestore is the live database and the Excel files are exports.

PHOTO:
Product images are compressed in the browser and stored as small data URLs in Firestore. This avoids requiring Firebase Storage for the basic free version. Keep product images reasonably sized.

PAYMENT:
The current version records Pending/Partial/Paid/Refunded manually. Real UPI/card gateway integration is a separate service and normally has transaction charges.

FREE HOSTING:
GitHub Pages can host these static HTML/CSS/JS files on GitHub Free. Firebase can remain the backend.
