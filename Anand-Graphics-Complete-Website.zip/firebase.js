import {initializeApp} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,sendPasswordResetEmail,signOut,updateProfile} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import {getFirestore,collection,addDoc,setDoc,doc,getDoc,getDocs,updateDoc,deleteDoc,serverTimestamp} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

const firebaseConfig={
 apiKey:"AIzaSyBlbAH-idhM51Ik4Ac90FGsNXEGe5P6RMo",
 authDomain:"anand-graphics.firebaseapp.com",
 projectId:"anand-graphics",
 storageBucket:"anand-graphics.firebasestorage.app",
 messagingSenderId:"463025918658",
 appId:"1:463025918658:web:da4688979188684738215b"
};
const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);
const ADMIN_EMAIL="anandpandey7919@gmail.com";
export{app,auth,db,ADMIN_EMAIL,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,sendPasswordResetEmail,signOut,updateProfile,collection,addDoc,setDoc,doc,getDoc,getDocs,updateDoc,deleteDoc,serverTimestamp};
